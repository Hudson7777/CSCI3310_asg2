package edu.cuhk.csci3310.cublossom;

// Name: Xu Haoran
// ID: 1155124383

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.Toast;
import java.util.ArrayList;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;

public class FlowerListAdapter extends RecyclerView.Adapter<FlowerListAdapter.FlowerViewHolder> {
    private final Context context;
    private final LayoutInflater layoutInflater;
    private final ArrayList<String> imagePathList;
    private final ArrayList<Flower> flowerList;

    public static String extraImagePath = null;
    public static String extraFlowerName = null;
    public static String extraGenus = null;
    public static int extraRichness = 0;

    public FlowerListAdapter(Context context, ArrayList<String> imagePathList, ArrayList<Flower> flowerList) {
        this.context = context;
        layoutInflater = LayoutInflater.from(context);
        this.imagePathList = imagePathList;
        this.flowerList = flowerList;
    }

    @NonNull
    @Override
    public FlowerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = layoutInflater.inflate(R.layout.imagelist_item, parent, false);
        return new FlowerViewHolder(itemView, this);
    }

    @Override
    public void onBindViewHolder(@NonNull FlowerViewHolder holder, int position) {
        String imagePath = imagePathList.get(position);
        int rating = flowerList.get(position).getRichness();
        Uri uri = Uri.parse(imagePath);
        holder.flowerImageItemView.setImageURI(null);
        holder.flowerImageItemView.setImageURI(uri);
        holder.flowerRichnessBar.setRating(rating);
    }

    @Override
    public int getItemCount() {
        return imagePathList.size();
    }

    public class FlowerViewHolder extends RecyclerView.ViewHolder {
        ImageView flowerImageItemView;
        RatingBar flowerRichnessBar;

        final FlowerListAdapter flowerListAdapter;

        public FlowerViewHolder(View itemView, FlowerListAdapter flowerListAdapter) {
            super(itemView);
            flowerImageItemView = itemView.findViewById(R.id.image);
            flowerRichnessBar = itemView.findViewById(R.id.flowerBar);
            this.flowerListAdapter = flowerListAdapter;
            flowerImageItemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getLayoutPosition();
                    Toast t = Toast.makeText(v.getContext(), "Clicked item at position " + position, Toast.LENGTH_SHORT);
                    t.show();
                    Intent intent = new Intent(context, DetailActivity.class);
                    extraImagePath = imagePathList.get(position);
                    extraFlowerName = flowerList.get(position).getFlowerName();
                    extraGenus = flowerList.get(position).getGenus();
                    extraRichness = flowerList.get(position).getRichness();
                    intent.putExtra("imagePath", extraImagePath);
                    intent.putExtra("flowerName", extraFlowerName);
                    intent.putExtra("genus", extraGenus);
                    intent.putExtra("richness", extraRichness);
                    intent.putExtra("position", position);
                    context.startActivity(intent);
                }
            });
        }
    }
}